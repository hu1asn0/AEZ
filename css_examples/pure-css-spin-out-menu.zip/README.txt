A Pen created at CodePen.io. You can find this one at http://codepen.io/billyysea/pen/AwitH.

 Hover the menu and all of it's items flare out!