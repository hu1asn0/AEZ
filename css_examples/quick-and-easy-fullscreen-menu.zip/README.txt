A Pen created at CodePen.io. You can find this one at http://codepen.io/luigimannoni/pen/ZYXEGa.

 Crafted and debugged in 5 minutes, IE10+ compatible. 
Might not be ideal for production but would help you if you need a quick working responsive and modern menu.