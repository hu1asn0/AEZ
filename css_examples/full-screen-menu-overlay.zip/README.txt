A Pen created at CodePen.io. You can find this one at http://codepen.io/ettrics/pen/JoaaxW.

 A full-screen menu, showcasing your brand and website navigation. Built using SCSS and vanilla JS.