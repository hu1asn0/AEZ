A Pen created at CodePen.io. You can find this one at http://codepen.io/mrspok407/pen/bwLwvL.

 Doesn't work in IE.

The thing is pretty easy customizable.
You can safely change font, font size, font color, animation speed. The first letter of a new string in array in JS will appear on a new slide.

Easy to create (or delete) a new slide:
1. Add new city in the array in JS.
2. Change number of slides variable and put a new image in scss list in CSS.

Based on dribbble shot by Giga Tamarashvili https://dribbble.com/shots/2998339-Booking