A Pen created at CodePen.io. You can find this one at http://codepen.io/marcbizal/pen/YXEmyQ.

 CSS Hamburger Animation taken from http://codepen.io/designcouch/details/Atyop/