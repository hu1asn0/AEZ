A Pen created at CodePen.io. You can find this one at http://codepen.io/suez/pen/ByvKXE.

 Sort of responsive. Tested in Chrome/FF/last IE, everywhere looks fine.

Source of inspiration - https://stupid-studio.com/ (their js is minified, so all code is mine, except some parts of svg, like viewBox/minHeight).