A Pen created at CodePen.io. You can find this one at http://codepen.io/suez/pen/vEZMoa.

 Source of inspiration - http://www.dehaus.be/

JS version (looks better) - http://codepen.io/suez/pen/wBeZbb