A Pen created at CodePen.io. You can find this one at http://codepen.io/maskedcoder/pen/zqgpr.

 Hover to reveal menu.

Menu icon done using pseudo-border method mentioned in this post: http://css-tricks.com/three-line-menu-navicon/.

_**Update 4/7/2015**: Fix menu hiding when cursor is moved between items; adjust the line-height so the text is vertically centered._