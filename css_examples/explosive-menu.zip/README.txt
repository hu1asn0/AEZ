A Pen created at CodePen.io. You can find this one at http://codepen.io/HarrisCarney/pen/EaEwbB.

 A, rather explosive, menu is just a click away. All you have to do is say fire.