$('.plus-btn').click(function(){
  $('body').toggleClass('menu-open');
})