A Pen created at CodePen.io. You can find this one at http://codepen.io/flurrd/pen/RaKJLY.

 Chrome and Firefox good... IE bad, no transition support for flex property.