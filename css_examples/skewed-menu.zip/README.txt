A Pen created at CodePen.io. You can find this one at http://codepen.io/kazzkiq/pen/qEMjaw.

 Using CSS3 properties to make a no-mainstream skewed menu.