A Pen created at CodePen.io. You can find this one at http://codepen.io/MAW/pen/XmozON.

 Full-Screen Slider ( GSAP Timeline ) #2:
http://codepen.io/MAW/pen/yYradO/