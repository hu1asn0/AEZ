A Pen created at CodePen.io. You can find this one at http://codepen.io/WispProxy/pen/EyLWKg.

 This Skewed Slider with Scrolling based on Pure JS and CSS (without libraries).