A Pen created at CodePen.io. You can find this one at http://codepen.io/CreativePunch/pen/lAHiu.

 A radial menu made with CSS3 and JavaScript