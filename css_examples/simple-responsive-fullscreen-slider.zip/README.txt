A Pen created at CodePen.io. You can find this one at http://codepen.io/jibbon/pen/BoisC.

 a simple fullscreen css & jQuery slider using translateX and translate3d smoothness!

If this can be further simplified suggestions are most welcome.