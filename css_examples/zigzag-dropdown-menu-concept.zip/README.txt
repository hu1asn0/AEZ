A Pen created at CodePen.io. You can find this one at http://codepen.io/catalinred/pen/kbscx.

 This is just another dropdown menu concept.