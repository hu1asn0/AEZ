A Pen created at CodePen.io. You can find this one at http://codepen.io/nathantaylor/pen/JEXgpj.

 Simple slider in a minimal style to show off images. part of the image pops out on each slide. Has some lag issues due to the blur and hi res images.
