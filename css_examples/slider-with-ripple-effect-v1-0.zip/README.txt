A Pen created at CodePen.io. You can find this one at http://codepen.io/pedro-castro/pen/dMxyde.

 This resource was inspired by the talented Tokito

https://dribbble.com/shots/2705517-boldybae