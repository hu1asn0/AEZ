A Pen created at CodePen.io. You can find this one at http://codepen.io/suez/pen/vAais.

 There is a bug with square backgrounds when you hovering buttons. Looks like it's a problem with this fancy hsla gradient background, but i don't wanna change it :)