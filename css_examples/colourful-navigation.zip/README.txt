A Pen created at CodePen.io. You can find this one at http://codepen.io/Lewitje/pen/ZGWpQQ.

 When you hover the colourful navigation the dot follows your moves to the current item.
When you leave it goes back to the active item.