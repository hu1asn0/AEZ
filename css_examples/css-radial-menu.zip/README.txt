A Pen created at CodePen.io. You can find this one at http://codepen.io/web-tiki/pen/ZYmZoV.

 Hover the burger to expand radial menu. Only CSS with transitions and transfroms. The radial menu system is responsive according to the viewport height/width