A Pen created at CodePen.io. You can find this one at http://codepen.io/arjancodes/pen/jErbyM.

 Material design inspired 'growing' menu? Not sure what to call it to be honest.

No jQuery used.