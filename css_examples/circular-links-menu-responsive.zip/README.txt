A Pen created at CodePen.io. You can find this one at http://codepen.io/rachsmith/pen/alnzE.

 I saw Andy Thelander make a sweet circular links menu so I made a circular links menu. It's not as cool but whatevs. All javascript cause I'm lazy for markup.

You can check out the original inspiration at http://thlndr.com