A Pen created at CodePen.io. You can find this one at http://codepen.io/apetrov/pen/AfhiD.

 Simple, basic and elegant CSS3 and jQuery driven fullscreen menu.