A Pen created at CodePen.io. You can find this one at http://codepen.io/fluxus/pen/gPWxXJ.

 Nothing too fancy here, as always I like things clean and simple.  Featuring the infamous burger menu, some sliding panels and subtle hover animation.

This was supposed to be the main nav for my redesigned portfolio, but I ditched it in favor of regular navigation,  the "say no to burger" articles got me :)) Hopefully the portfolio will be redesigned soon also, it is taking me ages!