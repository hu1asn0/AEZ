A Pen created at CodePen.io. You can find this one at http://codepen.io/larrygeams/pen/feoDc.

 Problem with long drop down menus? Well, try this simple solution with the use of javascript and jQuery.